<?php /* C:\xampp\htdocs\e_pasar\resources\views/admin/products/create.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row justify-content-center">
		<div class="col">
			<h2>Tambah Product</h2>
			<br />
			<?php if(count($errors)): ?>
			<div class="from-group">
				<div class="alert alert-danger">
					<ul>
						<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <li><?php echo e($error); ?></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
				</div>
			</div>
			<?php endif; ?>
			<br />

			<form action="<?php echo e(route('admin.products.store')); ?>" method="POST" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

				<div class="from-group">
					<label>Nama Produk</label>
					<input type="text" name="name" class="form-control" placeholder="Nama Produk">
				</div>
				<br>
				<div class="from-group">
					<label>Harga</label>
					<input type="number" name="price" class="form-control" placeholder="Harga">
				</div>
				<br>
				<div class="from-group">
					<label>Deskripsi</label>
					<textarea name="description" id="ckview"> </textarea>
					<script src="<?php echo e(url('plugins/tinymce/jquery.tinymce.min.js')); ?>"></script>
					<script src="<?php echo e(url('plugins/tinymce/tinymce.min.js')); ?>"></script>
					<script>tinymce.init({ selector:'#ckview' });</script>
				</div>
				<br>
				 <div class="form-group">
                    <label for="images">Images</label>
                    <input type="file" class="form-control-file" name="images[]" multiple>
	             </div>
				<button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Submit</button>
				<a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-primary"><i class="fas fa-undo"></i> Back</a>
			</form>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>