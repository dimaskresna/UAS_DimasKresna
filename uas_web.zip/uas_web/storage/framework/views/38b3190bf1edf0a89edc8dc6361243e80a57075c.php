<?php /* C:\xampp\htdocs\uas_web\resources\views/carts/index.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<br>
	<?php if($message = Session::get('success')): ?>
	<div class="alert alert-success">
		<p><?php echo e($message); ?></p>
	</div>
	<?php endif; ?>
	<table id="cart" class="table table-hover table-condensed">
		<thead class="thead-light">
			<tr>
				<th style="width:50%">Product</th>
				<th style="width:10%">Price</th>
				<th style="width:8%">Quantity</th>
				<th style="width:22%" class="text-center">Subtotal</th>
				<th style="width:10%"></th>
			</tr>
		</thead>
		<tbody>
			
			<?php $total = 0 ?>

			<?php if(session('cart')): ?>
			<?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

			<?php $total += $product['price'] * $product['quantity'] ?>

			<tr>
				<td data-th="Product">
					<div class="row">
						<div class="col-sm-3 hidden-xs">
					      <img src="<?php echo e(asset('/images/'. $product['image_url'])); ?>" style="width:100px;height:100px;">
						</div>
						<div class="col-sm-9">
							<h4 class="nomargin"><?php echo e($product['name']); ?></h4>
						</div>
					</div>
				</td>
				<td data-th="Price">Rp. <?php echo e($product['price']); ?></td>
				<td data-th="Quantity">
					<input type="number" value="<?php echo e($product['quantity']); ?>" class="form-control quantity" min="1" max="<?php echo e($product['stock']); ?>">
				</td>
				<td data-th="Subtotal" class="text-center">Rp. <?php echo e($product['price'] * $product['quantity']); ?></td>
				<td class="actions" data-th="">
					<button class="btn btn-primary btn-sm update-cart" data-id="<?php echo e($id); ?>"><i class="fas fa-sync"></i> Update</button>
					<button class="btn btn-danger btn-sm remove-from-cart" data-id="<?php echo e($id); ?>"><i class="fas fa-trash-alt"></i> Remove</button>
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
		</tbody>
		<tfoot>
			<tr>
				<td>
					<a href="<?php echo e(url('public')); ?>" class="btn btn-warning"><i class="fa fa-arrow-left"></i> Lanjutkan Belanja</a>
					
				</td>
				<td colspan="2" class="text-left h4"><b>TOTAL</b></td>
				<td colspan="" class="text-center h4"><b>Rp. <?php echo e($total); ?></b></td>
				<td colspan="" class="text-center h4"><a href="<?php echo e(route('admin.orders.create')); ?>" class="btn btn-success"><i class="fas fa-money-bill-wave"></i> Lanjutkan ke Pembayaran</a></td>				
			</tr>
			
		</tfoot>
	</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>