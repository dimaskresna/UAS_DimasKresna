<?php /* C:\xampp\htdocs\e_pasar\resources\views/layouts/script.blade.php */ ?>
<script src="<?php echo e(asset('/js/jquery-3.2.1.min.js')); ?>"></script>
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>

<script type="text/javascript">
	$(document).ready(function()
	{
		$(".update-cart").click(function (e)
		{
			e.preventDefault();
			console.log('aaaa');
			var ele = $(this);

			$.ajax(
			{
				url: '<?php echo e(route('carts.update')); ?>',
				method: "patch",
				data: {_token: '<?php echo e(csrf_token()); ?>', id: ele.attr("data-id"), quantity: ele.parents("tr").find(".quantity").val()},
				success: function(response)
				{
					window.location.reload();
				}
			});
		});

		$(".remove-from-cart").click(function (e)
		{
			e.preventDefault();

			var ele = $(this);

			if(confirm("Are you sure?"))
			{
				$.ajax(
				{
					url: '<?php echo e(route('carts.remove')); ?>',
					method: "DELETE",
					data: {_token: '<?php echo e(csrf_token()); ?>', id: ele.attr("data-id")},
					success: function(response)
					{
						window.location.reload();
					}
				});
			}
		});
	});
</script>
<?php echo $__env->yieldPushContent('script'); ?>