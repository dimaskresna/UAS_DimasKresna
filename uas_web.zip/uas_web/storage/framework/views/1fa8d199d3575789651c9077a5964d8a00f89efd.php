<?php /* C:\xampp\htdocs\e_pasar\resources\views/admin/products/index.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="container col-md-8">
	<div class="row justify-content-center">
		<div class="col">
			<br>
			<h2>List Product</h2>
			<div>
				<a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-primary"><i class="fas fa-plus-circle"></i> Tambah Produk</a>
			</div>
			<br>
			<?php if($message = Session::get('success')): ?>
			<div class="alert alert-success">
				<p><?php echo e($message); ?></p>
			</div>
			<?php endif; ?>
			<div class="table-responsive">
				<table class="table table-striped table-sm">
					<thead class="thead-dark">
						<tr>
							<th>No</th>
							<th>Name</th>
							<th>Price</th>
							<th>Created at</th>
							<th colspan="3">Action</th>
						</tr>
					</thead>
					<tbody class="tbody-light">
						<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($product['id']); ?></td>
							<td><?php echo e($product['name']); ?></td>
							<td>Rp. <?php echo e($product['price']); ?></td>
							<td><?php echo e($product['created_at']); ?></td>
							<td width="5%">
								<a class="btn btn-warning" href="<?php echo e(route('admin.products.edit',$product->id)); ?>"><i class="fas fa-sync"></i> Edit</a>
							</td>	
							<td width="5%">
								<a class="btn btn-success" href="<?php echo e(route('admin.products.show',$product->id)); ?>"><i class="far fa-eye"></i> Detail</a>
							</td>
							<td>
								<form action="<?php echo e(route('admin.products.destroy', $product->id)); ?>" method="post">
                				  <?php echo csrf_field(); ?>
                				  <?php echo method_field('DELETE'); ?>
                				  <button class="btn btn-danger" onclick="return confirm('Are you sure?')" type="submit"><i class="fas fa-trash-alt"></i> Delete</button>
                				
                				</form>
								<!-- <a class="btn btn-primary" href="<?php echo e(route('admin.products.destroy',$product->id)); ?>">Delete</a> -->
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
					
				</table>
				
			</div>
			
		</div>
		
	</div>
	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>