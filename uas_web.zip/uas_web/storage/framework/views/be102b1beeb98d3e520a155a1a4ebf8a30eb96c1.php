<?php /* C:\xampp\htdocs\uas_web\vendor\laravel\framework\src\Illuminate\Mail/resources/views/html/header.blade.php */ ?>
<tr>
    <td class="header">
        <a href="<?php echo e($url); ?>">
            <?php echo e($slot); ?>

        </a>
    </td>
</tr>
