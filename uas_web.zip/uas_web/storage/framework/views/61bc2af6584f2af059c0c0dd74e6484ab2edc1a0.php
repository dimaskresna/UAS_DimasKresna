<?php /* C:\xampp\htdocs\e_pasar\resources\views/admin/orders/index.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row justify-content-center">
		<div class="col">
			<br>
			<h2>List Order</h2>
			<?php if($message = Session::get('success')): ?>
			<div class="alert alert-success">
				<p><?php echo e($message); ?></p>
			</div>
			<?php endif; ?>
			<?php if(count($errors)): ?>
			<div class="alert alert-danger">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					  <li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<?php endif; ?>
			<div>
				<a href="<?php echo e(route('admin.orders.create')); ?>" class="btn btn-primary"><i class="fas fa-plus-circle"></i> Tambah Order</a>
			</div>
			<br>
			<div class="table-responsive">
				<table class="table table-striped table-sm">
					<thead class="thead-dark">
						<tr>
							<th>No.</th>
							<th>Harga Total</th>
							<th>Status</th>
							<th>Kode Pos</th>
							<th>Alamat Pengiriman</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($order['id']); ?></td>
							<td>Rp. <?php echo e($order['total_price']); ?></td>
							<td><?php echo e($order['status']); ?></td>
							<td><?php echo e($order['zip_code']); ?></td>
							<td><?php echo e($order['shipping_address']); ?></td>
							<td>
								<a class="btn btn-success btn-sm" href="<?php echo e(route('admin.orders.show' , $order->id)); ?>"><i class="far fa-eye"></i> Detail</a>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>