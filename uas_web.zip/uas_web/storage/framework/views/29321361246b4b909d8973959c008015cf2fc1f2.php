<?php /* C:\xampp\htdocs\uas_web\resources\views/public.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<!-- <div class="container"> -->
    <section class="page">
        <div class="row ml-4 mr-4">
        
        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-2 mb-4">
                <div class="card" style="width:10rem">
                    <div class="card-header bg-transparent">
                        <a href="<?php echo e(route('admin.products.show', $p->id)); ?>" class="nav-link text-dark">
                    <img src="<?php echo e(asset('/images/'. $p->images()->first()->image_src)); ?>" class=""  style="width:100px;height:100px;">
                      </a>
                    </div>
                    <div class="card-body">
                        <div class="text-center">
                            <a href="<?php echo e(route('admin.products.show', $p->id)); ?>" class="nav-link text-dark"><?php echo e($p->name); ?></a>
                            
                            <?php if($p->review->count(0)): ?>
                            <i class="fa fa-star text-warning"></i>
                            <i class="fa fa-star text-warning"></i>
                            <i class="fa fa-star text-warning"></i>
                            <i class="fa fa-star text-warning"></i>
                            <i class="fa fa-star text-warning"></i>
                            
                            <?php endif; ?>
                            <br>
                            <?php echo e($p->review()->count()); ?>

                            <br>
                            <div class="btn btn-primary btn-mini">Rp. <?php echo e($p->price); ?></div>
                        </div>
                        <br>
                        <a href="<?php echo e(route('carts.add',$p->id)); ?>" class="btn btn-outline-primary"><i class="fa fa-shopping-cart"></i> Add to Cart</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
    <?php echo e($product->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>