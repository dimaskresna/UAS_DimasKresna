<?php /* C:\xampp\htdocs\pasar\resources\views/admin/products/index.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="container col-md-8">
	<div class="row justify-content-center">
		<div class="col">
			<h2>Product</h2>
			<div>
				<a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-primary">Tambah Produk</a>

			</div>
			<br />
			<div class="table-responsive">
				<table class="table table-striped table-sm">
					<thead>
						<tr>
							<th>No</th>
							<th>Name</th>
							<th>Price</th>
							<th>Created at</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($product['id']); ?></td>
							<td><?php echo e($product['name']); ?></td>
							<td><?php echo e($product['price']); ?></td>
							<td><?php echo e($product['created_at']); ?></td>
							<td width="5%">
								<a class="btn btn-danger" href="<?php echo e(route('admin.products.edit',$product->id)); ?>">Edit</a>
							</td>	
							<td width="5%">
								<a class="btn btn-info" href="<?php echo e(route('admin.products.show',$product->id)); ?>">Detail</a>
							</td>
							<td>
								<form action="<?php echo e(route('admin.products.destroy', $product->id)); ?>" method="post">
                				  <?php echo csrf_field(); ?>
                				  <?php echo method_field('DELETE'); ?>
                				  <button class="btn btn-primary" onclick="return confirm('Are you sure?')" type="submit">Delete</button>
                				
                				</form>
								<!-- <a class="btn btn-primary" href="<?php echo e(route('admin.products.destroy',$product->id)); ?>">Delete</a> -->
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
					
				</table>
				
			</div>
			
		</div>
		
	</div>
	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>