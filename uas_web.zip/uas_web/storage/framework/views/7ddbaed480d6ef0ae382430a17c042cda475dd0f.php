<?php /* C:\xampp\htdocs\e_pasar\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php */ ?>
<?php echo e($slot); ?>

