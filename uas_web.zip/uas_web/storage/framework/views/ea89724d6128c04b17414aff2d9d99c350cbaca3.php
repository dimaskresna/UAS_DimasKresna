<?php /* D:\xampp\htdocs\ecommerce\resources\views/admin/products/index.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<section class="page">
			
					<table class="table table-striped table-sm">
						<thead class="thead-dark">
							<tr>
								<th>No</th>
								<th>Name</th>
								<th>Price</th>
								<th>Created at</th>
								<th colspan="3">Action</th>
							</tr>
						</thead>

						<tbody class="tbody-light">
	
							<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($product['id']); ?></td>
								<td><?php echo e($product['name']); ?></td>
								<td>Rp. <?php echo e(number_format($product->price,2)); ?></td>
								<td><?php echo e($product['created_at']); ?></td>
								<td width="5%">
									<a class="btn btn-warning" href="<?php echo e(route('admin.products.edit',$product->id)); ?>"><i class="fas fa-sync"></i> Edit</a>
								</td>	
								<td width="5%">
									<a class="btn btn-success" href="<?php echo e(route('admin.products.show',$product->id)); ?>"><i class="far fa-eye"></i> Detail</a>
								</td>
								<td>
									<form action="<?php echo e(route('admin.products.destroy', $product->id)); ?>" method="post">
									<?php echo csrf_field(); ?>
									<?php echo method_field('DELETE'); ?>
									<button class="btn btn-danger" onclick="return confirm('Are you sure?')" type="submit"><i class="fas fa-trash-alt"></i> Delete</button>
									
									</form>
									<!-- <a class="btn btn-primary" href="<?php echo e(route('admin.products.destroy',$product->id)); ?>">Delete</a> -->
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
					<?php echo e($products->links()); ?>

					</section>

					
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.products.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>