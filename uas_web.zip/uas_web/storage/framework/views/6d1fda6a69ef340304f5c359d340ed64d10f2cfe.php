<?php /* C:\xampp\htdocs\e_pasar\resources\views/show.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<!-- <div class="container col-md-8">
	<div class="row justify-content-center">
		<div class="col">
			<h2>Detail Produk</h2>
			<br />
			<div class="table-responsive">
				<table class="table table-hover h5">
					<tr>
						<td>No</td>
						<td>:</td>
						<td><?php echo e($products['id']); ?></td>
					</tr>
					<tr>
						<td>Name</td>
						<td>:</td>
						<td><?php echo e($products['name']); ?></td>
					</tr>
					<tr>
						<td>Price</td>
						<td>:</td>
						<td><?php echo e($products['price']); ?></td>
					</tr>
					<tr>
						<td>Description</td>
						<td>:</td>
						<td><?php echo e($products['description']); ?></td>
					</tr>
					<tr>
						<td>Created_At</td>
						<td>:</td>
						<td><?php echo e($products['created_at']); ?></td>
					</tr>
					<tr>
						<td>Images</td>	
						<td>:</td>
						<?php if(!$products->images()->get()->isEmpty()): ?>
						<td>
							 <?php $__currentLoopData = $products->images()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <image src="<?php echo e(asset('/images/'.$image->image_src)); ?>" class="img-thumbnail img-fluid" alt="<?php echo e($image->image_desc); ?>" style="width:200px;height:200px;"></image>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</td>
                        <?php endif; ?>
					</tr>					
				</table>
				<div>
					<a href="<?php echo e(url('public')); ?>" class="btn btn-primary">Back</a>
				</div>			
			</div>		
		</div>
	</div>
</div> -->

<div class="container">
	<div class="row">
		<div class="col-md-3">
		<?php if(!$products->images()->get()->isEmpty()): ?>
			 <?php $__currentLoopData = $products->images()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx2 => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			 	<?php if($idx2 == 0): ?>
            	<image src="<?php echo e(asset('/images/'.$image->image_src)); ?>" class="img-thumbnail img-fluid" alt="<?php echo e($image->image_desc); ?>" style="width:200px;height:200px;"></image>
            	<?php endif; ?>
        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
		</div>

		<div class="col-md-9">
			<h3><?php echo e($products -> name); ?></h3>
			<h4>Rp. <?php echo e($products -> price); ?></h4>
			<?php if(Auth::check()): ?>
				<div class="mt-4">
					<a href="<?php echo e(route('carts.add',$products->id)); ?>" class="btn btn-primary"><i class="fa fa-shopping-cart"></i> Add to Cart</a>
				</div>
			<?php endif; ?>
			<div class="mt-4">
				<ul class="nav nav-tabs">
					<li class="nav-item">
						<a class="nav-link active" href="#description" role="tab" data-toggle="tab">Deskripsi</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#review" role="tab" data-toggle="tab">Review</a>
					</li>
				</ul>

				<div class="tab-content mt-2">
					<div class="tab-pane fade in active show" role="tabpanel" id="description">
						<?php echo $products -> description; ?>

					</div>
					<div class="tab-pane fade" role="tabpanel" id="review">
						Content untuk review disini
					</div>
				</div>
			</div>	
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>