<?php /* C:\xampp\htdocs\ecommerce\resources\views/admin/products/edit.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row justify-content-center">
		<div class="col">
			<h2>Edit Produk</h2>
			<br />
			<?php if(count($errors)): ?>
			<div class="from-group">
				<div class="alert alert-danger">
					<ul>
						<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <li><?php echo e($error); ?></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
				</div>
			</div>
			<?php endif; ?>
			<br />

			<form action="<?php echo e(route('admin.products.update',$products->id)); ?>" enctype="multipart/form-data" method="POST">
				<?php echo e(csrf_field()); ?>

				 <?php echo method_field('PATCH'); ?>
				<div class="from-group">
					<label>Nama Produk</label>
					<input type="text" name="name" class="form-control" placeholder="Nama Produk" value="<?php echo e($products->name); ?>">
				</div>
				<div class="from-group">
					<label>Harga</label>
					<input type="number" name="price" class="form-control" placeholder="Harga" value="<?php echo e($products->price); ?>">
				</div>
				<div class="from-group">
					<label>Deskripsi</label>
					<textarea name="description" id="ckview"><?php echo e($products->description); ?> </textarea>
					<script src="<?php echo e(url('plugins/tinymce/jquery.tinymce.min.js')); ?>"></script>
					<script src="<?php echo e(url('plugins/tinymce/tinymce.min.js')); ?>"></script>
					<script>tinymce.init({ selector:'#ckview' });</script>
				</div>
				<div class="form-group">
                                <label for="images">Images</label>
                                <input type="file" class="form-control-file" name="images[]" id="images" multiple>
                </div>
				<button type="submit" class="btn btn-primary">Submit</button>
				<a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-primary">Back</a>
			</form>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>