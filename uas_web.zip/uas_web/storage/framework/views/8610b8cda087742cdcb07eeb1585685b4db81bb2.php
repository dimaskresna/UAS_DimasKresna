<?php /* D:\xampp\htdocs\ecommerce\resources\views/admin/orders/show.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row justify-content-center">
		<div class="col">
			<?php if($message = Session::get('success')): ?>
			<div class="alert alert-success">
				<p><?php echo e($message); ?></p>
			</div>
			<?php endif; ?>
			<br>
			<h2>List Order</h2>
			<br>
			<div class="table-responsive">
				<table class="table table-hover h5">
					
					<tr>
						<td width="20%">Status</td>
						<td width="2%">:</td>
						<td><?php echo e($order->status); ?></td>
					</tr>
					<tr>
						<td width="20%">name</td>
						<td width="2%">:</td>
						<td><?php echo e($order->name); ?></td>
					</tr>
					<tr>
						<td width="20%">telp</td>
						<td width="2%">:</td>
						<td><?php echo e($order->telp); ?></td>
					</tr>
					<tr>
						<td width="20%">Alamat Pengiriman</td>
						<td width="2%">:</td>
						<td><?php echo e($order->address); ?></td>
					</tr>
					<tr>
						<td>Kode Pos</td>
						<td>:</td>
						<td><?php echo e($order->zip); ?></td>
					</tr>
					<tr>
						<td>Harga Total</td>
						<td>:</td>
						<td>Rp. <?php echo e($order->total_price); ?></td>
					</tr>
				</table>
			</div>
		</div>
	</div>
	<br>
	<div class="row justify-content-center">
		<div class="col">
			<table id="cart" class="table table-hover table-condensed">
				<thead class="thead-dark">
					<tr>
						<th style="width:50%">Product</th>
						<th style="width:10%">Price</th>
						<th style="width:8%">Quantity</th>
						<th style="width:22%" class="text-center">Subtotal</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td data-th="Product">
							<div class="row">
								<div class="col-sm-3 hidden-xs">
									<img style="width:100px; height:100px"  src="<?php echo e(asset('/images/'. $orderItem->product->images->first()->image_src)); ?>">
								</div>
								<div class="col-sm-9">
									<a href="<?php echo e(url('show',$orderItem->product->id)); ?>"><h4 class="nomargin"><?php echo e($orderItem->product->name); ?></h4></a>
								</div>
							</div>
						</td>
						<td data-th="Price">
							Rp. <?php echo e($orderItem->price); ?>

						</td>
						<td data-th="Quantity">
							<?php echo e($orderItem->quantity); ?>

						</td>
						<td data-th="Subtotal" class="text-center">
							Rp. <?php echo e($orderItem->price * $orderItem->quantity); ?>

						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
	</div>
	<br>
	<div>
		<a href="<?php echo e(route('admin.orders.index')); ?>" class="btn btn-primary"><i class="fas fa-undo"></i> Back</a>
	</div>	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>