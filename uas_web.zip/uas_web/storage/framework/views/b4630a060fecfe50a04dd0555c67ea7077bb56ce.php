<?php /* C:\xampp\htdocs\ecommerce\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php */ ?>
<?php echo e($slot); ?>

