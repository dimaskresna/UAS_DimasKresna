<?php /* C:\xampp\htdocs\pasar\resources\views/admin/products/show.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="container col-md-8">
	<div class="row justify-content-center">
		<div class="col">
			<h2>Hasil Produk</h2>
			<br />
			<div class="table-responsive">
				<table class="table table-hover table-sm">
					<tr>
						<td>No</td>
						<td>Name</td>
						<td>Price</td>
						<td>Description</td>
						<td>Created_At</td>
												<td>Images</td>						
					</tr>
					<tr>
						<td><?php echo e($products['id']); ?></td>
						<td><?php echo e($products['name']); ?></td>
						<td><?php echo e($products['price']); ?></td>
						<td><?php echo e($products['description']); ?></td>
						<td><?php echo e($products['created_at']); ?></td>
						<?php if(!$products->images()->get()->isEmpty()): ?>
						<td>
							 <?php $__currentLoopData = $products->images()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <image src="<?php echo e(asset('/images/'.$image->image_src)); ?>" class="img-thumbnail img-fluid" alt="<?php echo e($image->image_desc); ?>" style="width:200px;height:200px;"></image>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</td>
                        <?php endif; ?>
					</tr>
					
				</table>
				<div>
						<a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-primary">Back</a>
					</div>
				
			</div>
			
		</div>
		
	</div>
	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>