<?php /* C:\xampp\htdocs\e_pasar\resources\views/public.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<!-- <div class="container col-md-8">
	<div class="row justify-content-center">
		<div class="col">
			<h2>Product</h2>
			
			<br />
			<div class="table-responsive">
				<table class="table table-sm">
					<thead class="thead-dark">
						<tr>
							<th>No</th>
							<th>Name</th>
							<th>Price</th>
							<th>Created at</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($product['id']); ?></td>
							<td><?php echo e($product['name']); ?></td>
							<td><?php echo e($product['price']); ?></td>
							<td><?php echo e($product['created_at']); ?></td>
							<td>
								<a class="btn btn-success" href="<?php echo e(url('show',$product->id)); ?>">Detail</a>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
					
				</table>
				
			</div>
			
		</div>
		
	</div>
	
</div> -->
<div class="container">
	<?php if($message = Session::get('success')): ?>
	<div class="alert alert-success">
		<p><?php echo e($message); ?></p>
	</div>
	<?php endif; ?>
	
	<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php if($idx == 0 || $idx % 4 == 0): ?>
		<div class="row mt-4">
		<?php endif; ?>

		<div class="col">
			<div class="card">
				<?php if(!$product->images()->get()->isEmpty()): ?>
					 <?php $__currentLoopData = $product->images()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx2 => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					 	<?php if($idx2 == 0): ?>
                    	<image src="<?php echo e(asset('/images/'.$image->image_src)); ?>" class="card-img-top" alt="<?php echo e($image->image_desc); ?>" height="300" width="100"></image>
                    	<?php endif; ?>
                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
				<div class="card-body">
					<center>
						<h5 class="card-title">
							<a href="<?php echo e(url('show',$product->id)); ?>">
								<?php echo e($product->name); ?>

							</a>
						</h5>
						<p class="card-text">
							Rp. <?php echo e($product->price); ?>

						</p>
						<?php if(Auth::check()): ?>
							<a class="btn btn-primary" href="<?php echo e(route('carts.add',$product->id)); ?>"><i class="fa fa-shopping-cart"></i> Add to Cart</a>
						<?php endif; ?>
					</center>
				</div>
			</div>
		</div>

		<?php if($idx > 0 && $idx % 4 == 3): ?>
		</div>
		<?php endif; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>